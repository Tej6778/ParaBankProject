package com.Modules;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

@Test
public class M_16_LatestNews {
WebDriver driver=null;
	public void LatestNews(WebDriver driver) throws InterruptedException {

//		WebDriverManager.chromedriver().setup();
//		driver=new ChromeDriver();
//		driver.get("https://parabank.parasoft.com/parabank/index.htm");
		Thread.sleep(2000);
		
		Actions at = new Actions(driver);
		
		WebElement PR= driver.findElement(By.partialLinkText("ParaBank Is Now Re-Opened"));
		WebElement OBP= driver.findElement(By.partialLinkText("New! Online "));
		WebElement OAT= driver.findElement(By.partialLinkText("New! Online Account "));
		WebElement RM= driver.findElement(By.xpath("//*[@id=\"rightPanel\"]/p[1]/a"));
		at.moveToElement(PR).click().perform();
		Thread.sleep(2000);
		driver.navigate().back();
		
		at.moveToElement(OBP).click().perform();
		Thread.sleep(2000);
		driver.navigate().back();
		
		at.moveToElement(OAT).click().perform();
		Thread.sleep(2000);
		driver.navigate().back();
		
		at.moveToElement(RM).click().perform();
		Thread.sleep(2000);
		driver.navigate().back();
	}
	
}
