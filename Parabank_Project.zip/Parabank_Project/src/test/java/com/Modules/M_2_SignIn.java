package com.Modules;

import java.io.File;
import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Test;

import com.google.common.io.Files;

import io.github.bonigarcia.wdm.WebDriverManager;

public class M_2_SignIn {

	public String [][] read() throws InvalidFormatException, IOException {
	
	String [][]Data= null;
	
	String filepath="C:\\Users\\tejas\\Desktop\\ParabankRegistration.xlsx";
	
	File f=new File(filepath);
	
	XSSFWorkbook wrkbuk= new XSSFWorkbook(f);
	
	Sheet sht= wrkbuk.getSheet("Sheet5");
	
	int row= sht.getPhysicalNumberOfRows();
	
	Data= new String [row][];
	
	for (int i = 0; i < Data.length; i++) {
		Row rw= sht.getRow(i);
		
	int col=rw.getPhysicalNumberOfCells();
	
	Data [i]= new String[col];
	
	for (int j = 0; j < Data[i].length; j++) {
	Cell cl=rw.getCell(j);
	
	cl.setCellType(CellType.STRING);

	Data[i][j]=cl.getStringCellValue();
	}
	}
		
	return Data;
		
	}
	
	WebDriver driver=null;
	@Test
	public void Register() throws InterruptedException, InvalidFormatException, IOException {
		WebDriverManager.chromedriver().setup();	
	driver=new ChromeDriver();	
	String Data[][]=read();
	for (int i = 0; i < 1; i++) {

	driver.manage().window().maximize();
	
	driver.get("https://parabank.parasoft.com/parabank/index.htm");
	Thread.sleep(2000);
	
	driver.findElement(By.linkText("Register")).click();
	Thread.sleep(2000);
	
	JavascriptExecutor up= (JavascriptExecutor)driver;
	up.executeScript("window.scrollBy(0, 500)", "");
	
	driver.findElement(By.id("customer.firstName")).sendKeys(Data[i][0]);
	Thread.sleep(2000);
	
	driver.findElement(By.id("customer.lastName")).sendKeys(Data[i+1][0]);
	Thread.sleep(2000);
	
	driver.findElement(By.id("customer.address.street")).sendKeys(Data[i+2][0]);
	Thread.sleep(2000);
	
	driver.findElement(By.id("customer.address.city")).sendKeys(Data[i+3][0]);
	Thread.sleep(2000);
	
	driver.findElement(By.id("customer.address.state")).sendKeys(Data[i+4][0]);
	Thread.sleep(2000);
	
	driver.findElement(By.id("customer.address.zipCode")).sendKeys(Data[i+5][0]);
	Thread.sleep(2000);
	
	driver.findElement(By.id("customer.phoneNumber")).sendKeys(Data[i+6][0]);
	Thread.sleep(2000);
	
	driver.findElement(By.id("customer.ssn")).sendKeys(Data[i+7][0]);
	Thread.sleep(2000);
	
	driver.findElement(By.id("customer.username")).sendKeys(Data[i+8][0]);
	Thread.sleep(2000);
	
	driver.findElement(By.id("customer.password")).sendKeys(Data[i+9][0]);
	Thread.sleep(2000);
	
	driver.findElement(By.id("repeatedPassword")).sendKeys(Data[i+10][0]);
	Thread.sleep(5000);

	driver.findElement(By.xpath("//*[@value='Register']")).click();
	Thread.sleep(5000);
	
	String Title=driver.getTitle();
	Thread.sleep(1000);
	
	if (Title.equals("ParaBank | Customer Created")) {
	System.out.println("Successfull login by FullyFIlled Info");	
	} else {
	System.out.println("Unsuccessfull info");	
	}
	
	File F=((RemoteWebDriver) driver).getScreenshotAs(OutputType.FILE);
	Files.copy(F, new File("C:\\Users\\tejas\\ParabankProjectScreenshot\\SuccessfullLogin with all fullyfilled info.png"));
	
	driver.close();
	}
	}	
}
