package com.Modules;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class M_3_Login {

	public void Username(WebDriver driver, String Username) throws InterruptedException {
	driver.findElement(By.name("username")).sendKeys(Username);	
	Thread.sleep(1000);
	}
	
	public void Password(WebDriver driver, String Password) throws InterruptedException {
	driver.findElement(By.name("password")).sendKeys(Password);	
	Thread.sleep(1000);
	}
	
	public void Login(WebDriver driver) throws InterruptedException {
	driver.findElement(By.xpath("//*[@value='Log In']")).click();	
	Thread.sleep(1000);
	}
}
