package com.Modules;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class M_5_AccountOverview {
@Test
	public void AcOverview(WebDriver driver) throws InterruptedException {
//		WebDriverManager.chromedriver().setup();
//		WebDriver driver= new ChromeDriver();
//
//		driver.get("https://parabank.parasoft.com/parabank/index.htm");
//		Thread.sleep(2000);
//			
//		driver.findElement(By.name("username")).sendKeys("MD@gmail.com");
//		Thread.sleep(1000);
//		driver.findElement(By.name("password")).sendKeys("MD@5678");
//		Thread.sleep(1000);
//		driver.findElement(By.xpath("//*[@value='Log In']")).click();
//		Thread.sleep(1000);
		
		driver.findElement(By.linkText("Accounts Overview")).click();
		Thread.sleep(1000);
		
		String string=driver.getTitle();
		if (string.equals("ParaBank | Accounts Overview")) {
			System.out.println("Account Overview Passed");
		} else {
			System.out.println("Account Overview Failed");
		}
	}
}
