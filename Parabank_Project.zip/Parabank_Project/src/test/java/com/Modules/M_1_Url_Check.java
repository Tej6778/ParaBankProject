package com.Modules;

import java.sql.Driver;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class M_1_Url_Check {

@Test
public void main() throws InterruptedException {
//System.setProperty("webdriver.edge.driver", "C:\\Users\\tejas\\edgedriver_win64\\msedgedriver.exe");
//WebDriver driver= new EdgeDriver();
WebDriverManager.chromedriver().setup();
WebDriver driver= new ChromeDriver();

driver.get("https://parabank.parasoft.com/parabank/index.htm");
Thread.sleep(2000);

System.out.println(driver.getCurrentUrl());

if (driver.getCurrentUrl().equals("https://parabank.parasoft.com/parabank/index.htm")) {
	System.out.println("Valid URl!!! Test is passed");
} else {
	System.out.println("Test Failed");
}

String ttl = driver.getTitle();


if (driver.getTitle().equals(ttl)) {
	System.out.println(ttl+", !!! valid Title");
} else {
	System.out.println("Invalid title");
}

}		
}
