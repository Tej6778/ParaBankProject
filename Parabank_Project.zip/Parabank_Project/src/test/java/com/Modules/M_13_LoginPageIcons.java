package com.Modules;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;


public class M_13_LoginPageIcons {
WebDriver driver=null;
@Test (priority = 1)
public void Icons(WebDriver driver) throws InterruptedException {
	
//		WebDriverManager.chromedriver().setup();
//		driver= new ChromeDriver();
//		driver.manage().window().maximize();
//		
//		driver.get("https://parabank.parasoft.com/parabank/index.htm");
//		Thread.sleep(1000);
		
		Actions at= new Actions(driver);
		
		WebElement Abt= driver.findElement(By.linkText("about"));
		at.moveToElement(Abt).click().perform();
		Thread.sleep(1000);
		String Abttitle= driver.getTitle();
		if (driver.getTitle().equals(Abttitle)) {
			System.out.println("Valid About Icon");
		} else {
			System.out.println("InValid About Icon");
		}
		driver.navigate().back();
		
		Thread.sleep(1000);
		
		WebElement Home= driver.findElement(By.linkText("home"));
		at.moveToElement(Home).click().perform();
		Thread.sleep(1000);
		String Homtitle= driver.getTitle();
		if (driver.getTitle().equals(Homtitle)) {
			System.out.println("Valid Home Icon");
		} else {
			System.out.println("InValid Home Icon");
		}
		driver.navigate().back();
		
		Thread.sleep(1000);
		
		WebElement cnt= driver.findElement(By.linkText("contact"));
		at.moveToElement(cnt).click().perform();
		Thread.sleep(1000);
		String Contitle= driver.getTitle();
		if (driver.getTitle().equals(Contitle)) {
			System.out.println("Valid Contact Icon");
		} else {
			System.out.println("InValid Contact Icon");
		}		
		driver.navigate().back();
		
	}
	
@Test (priority = 2)
		public void Contact(WebDriver driver) throws InterruptedException {
//	WebDriverManager.chromedriver().setup();
//	driver= new ChromeDriver();
//	driver.manage().window().maximize();
//	
//	driver.get("https://parabank.parasoft.com/parabank/index.htm");
//	Thread.sleep(1000);
//		driver.findElement(By.linkText("contact")).click();
		Thread.sleep(2000);		
		
		driver.findElement(By.id("name")).sendKeys("Thor");
		Thread.sleep(1000);
		driver.findElement(By.id("email")).sendKeys("Thor_the_great@gmail.com");
		Thread.sleep(1000);
		driver.findElement(By.id("phone")).sendKeys("1234567890");
		Thread.sleep(1000);
		driver.findElement(By.id("message")).sendKeys("Valid User");
		Thread.sleep(1000);
		driver.findElement(By.cssSelector("input.button")).click();
		
	}
}
