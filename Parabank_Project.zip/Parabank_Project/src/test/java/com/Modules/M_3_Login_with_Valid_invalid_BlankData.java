package com.Modules;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Test;

import com.google.common.io.Files;

import io.github.bonigarcia.wdm.WebDriverManager;

public class M_3_Login_with_Valid_invalid_BlankData {

@Test (priority = 1)
	public void Vaiid_Login() throws InterruptedException, IOException {
	WebDriverManager.chromedriver().setup();
	WebDriver driver= new ChromeDriver();
	driver.manage().window().maximize();
	driver.get("https://parabank.parasoft.com/parabank/index.htm");
	Thread.sleep(2000);
	
	driver.findElement(By.name("username")).sendKeys("MD@gmail.com");
	Thread.sleep(1000);
	driver.findElement(By.name("password")).sendKeys("MD@5678");
	Thread.sleep(1000);
	driver.findElement(By.xpath("//*[@value='Log In']")).click();
	Thread.sleep(5000);
	
	String ss=driver.getTitle();
	
	if (ss.equals("ParaBank | Accounts Overview")) {
		System.out.println("Test Pass ! Login with valid credentials");
	} else {
		System.out.println("Test Failed! Didn't_Login with valid credentials");
	}
	
	driver.close();
		
	}
	
@Test (priority = 2)	
	public void Invalid_Login() throws InterruptedException, IOException {
	WebDriverManager.chromedriver().setup();
	WebDriver driver= new ChromeDriver();
	driver.manage().window().maximize();
	driver.get("https://parabank.parasoft.com/parabank/index.htm");
	Thread.sleep(2000);	
		
	driver.findElement(By.name("username")).sendKeys("MD@gmail.com");
	Thread.sleep(1000);
	driver.findElement(By.name("password")).sendKeys("CB5678");
	Thread.sleep(1000);
	driver.findElement(By.xpath("//*[@value='Log In']")).click();
	Thread.sleep(5000);	

	String Il=driver.getTitle();
	System.out.println(Il);
	
	if (Il.equals("ParaBank | Accounts Overview")) {
		File f= ((RemoteWebDriver) driver).getScreenshotAs(OutputType.FILE);
		Files.copy(f, new File("C:\\Users\\tejas\\Screenshot\\InValid_Login.png"));
		System.out.println("Test Failed! Login with invalid credentials");	
	} else {
		System.out.println("Test pass! Didn't login with invalid credentials");	
	}
	driver.close();
	}

@Test (priority = 3)
	public void Blank_Login() throws InterruptedException, IOException {
	WebDriverManager.chromedriver().setup();
	WebDriver driver= new ChromeDriver();
	driver.manage().window().maximize();
	driver.get("https://parabank.parasoft.com/parabank/index.htm");
	Thread.sleep(2000);	
			
	driver.findElement(By.name("username")).sendKeys("MD@gmail.com");
	Thread.sleep(1000);
	driver.findElement(By.name("password")).sendKeys("");
	Thread.sleep(1000);
	driver.findElement(By.xpath("//*[@value='Log In']")).click();
	Thread.sleep(5000);	
			
	String Il=driver.getTitle();
		
	if (Il.equals("ParaBank | Accounts Overview")) {
		File f= ((RemoteWebDriver) driver).getScreenshotAs(OutputType.FILE);
		Files.copy(f, new File("C:\\Users\\tejas\\Screenshot\\Blank_Login.png"));
		System.out.println("Test Failed! Login with Blank credentials");	
	} else {
		System.out.println("Test pass! Didn't login with Blank credentials");	
	}
	}	

}
