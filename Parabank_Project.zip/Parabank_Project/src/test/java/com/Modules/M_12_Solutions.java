package com.Modules;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

@Test
public class M_12_Solutions {

	public void solution(WebDriver driver) throws InterruptedException {
	
//		WebDriverManager.chromedriver().setup();
//		WebDriver driver=new ChromeDriver();
//		driver.manage().window().maximize();
//		
//		driver.get("https://parabank.parasoft.com/parabank/index.htm");
//		Thread.sleep(2000);
		
		driver.findElement(By.linkText("About Us")).click();
        Thread.sleep(2000);
		driver.navigate().back();
		
		driver.findElement(By.linkText("Services")).click();
		Thread.sleep(2000);
		JavascriptExecutor up= (JavascriptExecutor)driver;
		up.executeScript("window.scrollBy(0, 500)" , "");
		Thread.sleep(1000);
		up.executeScript("window.scrollBy(0, 500)" , "");
		Thread.sleep(1000);
		up.executeScript("window.scrollBy(0, 500)" , "");
		Thread.sleep(2000);
		driver.navigate().back();
		
		driver.findElement(By.linkText("Products")).click();
		Thread.sleep(2000);
		
		WebElement Pr=driver.findElement(By.linkText("Products"));
		WebElement Pr_1=driver.findElement(By.xpath("//span[text()='C/C++test']")); 
		WebElement Pr_2=driver.findElement(By.xpath("//span[text()='Jtest']"));
		WebElement Pr_3=driver.findElement(By.xpath("//span[text()='dotTEST']"));
		WebElement Pr_4=driver.findElement(By.xpath("//span[text()='Insure++']"));
		WebElement Pr_5=driver.findElement(By.xpath("//span[text()='DTP']"));
		WebElement Pr_6=driver.findElement(By.xpath("//span[text()='CTP']"));
		WebElement Pr_7=driver.findElement(By.xpath("//span[text()='Selenic']"));
		WebElement Pr_8=driver.findElement(By.xpath("//span[text()='SOAtest']"));
		WebElement Pr_9=driver.findElement(By.xpath("//span[text()='Virtualize']"));
		
		Actions atActions= new Actions(driver);
		
		atActions.moveToElement(Pr).perform();
		Thread.sleep(5000);
		atActions.moveToElement(Pr_1).perform();
		Thread.sleep(3000);
		atActions.moveToElement(Pr_2).perform();
		Thread.sleep(3000);
		atActions.moveToElement(Pr_3).perform();
		Thread.sleep(3000);
		atActions.moveToElement(Pr_4).perform();
		Thread.sleep(3000);
		atActions.moveToElement(Pr_5).perform();
		Thread.sleep(3000);
		atActions.moveToElement(Pr_6).perform();
		Thread.sleep(3000);
		atActions.moveToElement(Pr_7).perform();
		Thread.sleep(3000);
		atActions.moveToElement(Pr_8).perform();
		Thread.sleep(3000);
		atActions.moveToElement(Pr_9).perform();
		Thread.sleep(3000);
		
		driver.navigate().back();
		
		driver.findElement(By.linkText("Locations")).click();
		Thread.sleep(3000);
		
		driver.close();
	
		
	}
	
}
