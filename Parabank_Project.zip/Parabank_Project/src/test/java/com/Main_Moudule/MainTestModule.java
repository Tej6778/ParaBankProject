package com.Main_Moudule;

import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.BrowserSelection.SearchEngine;
import com.Modules.M_10_RequestLoan;
import com.Modules.M_11_logout;
import com.Modules.M_12_Solutions;
import com.Modules.M_13_LoginPageIcons;
import com.Modules.M_14_AtmServices;
import com.Modules.M_15_OnlineServices;
import com.Modules.M_16_LatestNews;
import com.Modules.M_17_FooterLinks;
import com.Modules.M_3_Login;
import com.Modules.M_4_OpenNewAccount;
import com.Modules.M_5_AccountOverview;
import com.Modules.M_6_TransferFunds;
import com.Modules.M_7_BillPay;
import com.Modules.M_8_FindTransactions;
import com.Modules.M_9_UpdateContactInfo;

public class MainTestModule {
WebDriver driver=null;
M_3_Login LP=null;
M_5_AccountOverview AO=null;
M_4_OpenNewAccount ONA=null;
M_6_TransferFunds TF=null;
M_7_BillPay BP=null;
M_8_FindTransactions FT=null;
M_9_UpdateContactInfo UCI=null;
M_10_RequestLoan RL=null;
M_11_logout LO=null;
M_12_Solutions So=null;
M_13_LoginPageIcons LPI=null;
M_14_AtmServices AS=null;
M_15_OnlineServices OS=null;
M_16_LatestNews LN=null;
M_17_FooterLinks FL=null;

	@BeforeTest
	public void Browser() throws InterruptedException {
		driver= new SearchEngine().Edgebrowser("Edge", "https://parabank.parasoft.com/parabank/index.htm");	
		Thread.sleep(2000);
		}

	@Test(priority = 1)
	public void Loginn() throws InterruptedException {
		LP=new M_3_Login();
		LP.Username(driver, "DF@gmail.com");
		LP.Password(driver, "DF@5678");
		LP.Login(driver);
		}

	@Test(priority = 2)
	public void AcoountOverview() throws InterruptedException {
		AO=new M_5_AccountOverview();
		AO.AcOverview(driver);	
		}

	@Test(priority = 3)
	public void OpenNewAcc() throws InterruptedException, IOException {
		ONA= new M_4_OpenNewAccount();
		ONA.NewAccount(driver);
		}

	@Test(priority = 4)
	public void TransferFUnd() throws InterruptedException, IOException {
		TF=new M_6_TransferFunds();
		TF.Tfunds(driver);
		}

	@Test(priority = 5)
	public void Billpay() throws InvalidFormatException, InterruptedException, IOException {
		BP=new M_7_BillPay();
		BP.Bpay(driver);
		}

	@Test(priority = 6)
	public void FindTransactionsss() throws InterruptedException {
		FT=new M_8_FindTransactions();
		FT.FindTransactions(driver);
		FT.BY_ID(driver);
		FT.BY_Date(driver);
		FT.BY_DateRange(driver);
		FT.BY_Amount(driver);
		}

	@Test(priority = 7)
	public void UpdateConInfo() throws InterruptedException, IOException {
		UCI=new M_9_UpdateContactInfo();
		UCI.UpdateInfo(driver);
		}

	@Test(priority = 8)
	public void ReqLoan() throws InterruptedException, IOException {
		RL=new M_10_RequestLoan();
		RL.Loan_with_downpayment(driver);
		RL.Loan_with_high_downpayment(driver);
		RL.Loan_with_0_downpayment(driver);
		}

	@Test(priority = 9)
	public void Logout() throws InterruptedException {
		LO=new M_11_logout();
		LO.Logout(driver);
		}

	@Test(priority = 10)
	public void Solutions() throws InterruptedException {
		So=new M_12_Solutions();
		So.solution(driver);
		}

	@Test(priority = 11)
	public void LoginPageIconss() throws InterruptedException {
		LPI=new M_13_LoginPageIcons();
		LPI.Icons(driver);
		LPI.Contact(driver);
		}

	@Test(priority = 12)
	public void AtmServicess() throws InterruptedException {
		AS=new M_14_AtmServices();
		AS.AtmServices(driver);
		}

	@Test(priority = 13)
	public void Onlinservicess() throws InterruptedException {
		OS= new M_15_OnlineServices();
		OS.OnlineServices(driver);
		}

	@Test(priority = 14)
	public void LatestNews() throws InterruptedException {
		LN=new M_16_LatestNews();
		LN.LatestNews(driver);
		}

	@Test(priority = 15)
	public void FooterLink() throws InterruptedException {
		FL=new M_17_FooterLinks();
		FL.FLinks(driver);
		}

	@Test(priority = 16)
	public void Project_Complete() {
		System.out.println("TestProject Completed");
		}
}
