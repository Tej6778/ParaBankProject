package com.Modules;

import java.io.File;
import java.io.IOException;

import org.checkerframework.checker.units.qual.s;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import com.google.common.io.Files;

import io.github.bonigarcia.wdm.WebDriverManager;

public class M_6_TransferFunds {
@Test
	public void Tfunds(WebDriver driver) throws InterruptedException, IOException {
//		WebDriverManager.chromedriver().setup();
//		WebDriver driver= new ChromeDriver();
//
//		driver.get("https://parabank.parasoft.com/parabank/index.htm");
//		Thread.sleep(2000);
//			
//		driver.findElement(By.name("username")).sendKeys("MD@gmail.com");
//		Thread.sleep(1000);
//		driver.findElement(By.name("password")).sendKeys("MD@5678");
//		Thread.sleep(1000);
//		driver.findElement(By.xpath("//*[@value='Log In']")).click();
//		Thread.sleep(1000);
		
		driver.findElement(By.linkText("Transfer Funds")).click();
		Thread.sleep(1000);
		
		driver.findElement(By.id("amount")).sendKeys("50");
		Thread.sleep(1000);
		
		WebElement W1=	driver.findElement(By.id("fromAccountId"));
		Select S=new Select(W1);
		S.selectByVisibleText("14232");
		
		WebElement W2=	driver.findElement(By.id("toAccountId"));
		Select S1=new Select(W2);
		S1.selectByVisibleText("14343");
				
		driver.findElement(By.xpath("//*[@type='submit']")).click();
		Thread.sleep(1000);
			
		String ss=driver.findElement(By.cssSelector("h1[class='title']")).getText();
		if (ss.equals("Transfer Complete!")) {
			System.out.println("Test passed ! Fund Transfered successfully");
		} else {
			File f= ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			Files.copy(f, new File("C:\\Users\\tejas\\ParabankProjectScreenshot\\Unsuccessful_Fund_Transfer.png"));
			System.out.println("Unsuccessfull Fund Transfer");	
		}
	}
}
