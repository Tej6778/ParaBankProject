package com.Modules;

import java.io.File;
import java.io.IOException;

import org.checkerframework.checker.units.qual.s;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import com.google.common.io.Files;

import io.github.bonigarcia.wdm.WebDriverManager;

public class M_4_OpenNewAccount {
@Test
public void NewAccount(WebDriver driver) throws InterruptedException, IOException {
//	WebDriverManager.chromedriver().setup();
//	WebDriver driver= new ChromeDriver();
//
//	driver.get("https://parabank.parasoft.com/parabank/index.htm");
//	Thread.sleep(2000);
//		
//	driver.findElement(By.name("username")).sendKeys("MD@gmail.com");
//	Thread.sleep(1000);
//	driver.findElement(By.name("password")).sendKeys("MD@5678");
//	Thread.sleep(1000);
//	driver.findElement(By.xpath("//*[@value='Log In']")).click();
//	Thread.sleep(1000);
	
	driver.findElement(By.linkText("Open New Account")).click();
	Thread.sleep(1000);
	
	WebElement W1=driver.findElement(By.cssSelector("select#type"));
	Select S=new Select(W1);
	S.selectByVisibleText("SAVINGS");
	Thread.sleep(2000);
	
	driver.findElement(By.xpath("//*[@type='submit']")).click();
	Thread.sleep(2000);
	
	String Title=driver.getTitle();
	System.out.println(Title);
		if (Title.equals("ParaBank | Open Account")) {
//		File f= ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
//		Files.copy(f, new File("C:\\Users\\tejas\\ParabankProjectScreenshot\\New_Acc_Opened.png"));		
		System.out.println("Test Passed ! New Account Opened");
	} else {
		System.out.println("Test Failed of Account Opening");
	}
	
	driver.findElement(By.id("newAccountId")).click();
	Thread.sleep(1000);

	WebElement W2=driver.findElement(By.id("month"));
	Select S1=new Select(W2);
	S1.selectByVisibleText("May");
	Thread.sleep(1000);
	
	WebElement W3=driver.findElement(By.id("transactionType"));
	Select S2=new Select(W3);
	S2.selectByVisibleText("Credit");
	Thread.sleep(1000);
	driver.findElement(By.linkText("Funds Transfer Received")).click();
	Thread.sleep(1000);
	
	String st= driver.getTitle();
	if (st.equals("ParaBank | Transaction Details")) {
		System.out.println("Fund Transaction Passed");
	} else {
		System.out.println("Fund Transaction Failed");
	}
	
	driver.navigate().back();
	driver.findElement(By.xpath("//*[@value='Go']")).click();
	Thread.sleep(1000);
}
}
