package com.Modules;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Test;

import com.google.common.io.Files;

import io.github.bonigarcia.wdm.WebDriverManager;

public class M_9_UpdateContactInfo {
WebDriver driver=null;
	@Test
	public void UpdateInfo(WebDriver driver) throws InterruptedException, IOException {
//		WebDriverManager.chromedriver().setup();
//		driver= new ChromeDriver();
//		driver.get("https://parabank.parasoft.com/parabank/index.htm");
//		Thread.sleep(2000);
//		
//		driver.manage().window().maximize();
//			
//		driver.findElement(By.name("username")).sendKeys("KY@gmail.com");
//		Thread.sleep(1000);
//		driver.findElement(By.name("password")).sendKeys("KY5678");
//		Thread.sleep(1000);
//		driver.findElement(By.xpath("//*[@value='Log In']")).click();
//		Thread.sleep(1000);	
		driver.findElement(By.linkText("Update Contact Info")).click();
		Thread.sleep(1000);	
		
		driver.findElement(By.id("customer.phoneNumber")).clear();
		Thread.sleep(1000);
		
		driver.findElement(By.id("customer.phoneNumber")).sendKeys("1234567890");
		Thread.sleep(1000);
		
		driver.findElement(By.xpath("//*[@value='Update Profile']")).click();
		Thread.sleep(1000);
		
		File file= ((RemoteWebDriver) driver).getScreenshotAs(OutputType.FILE);
		Files.copy(file, new File("C:\\Users\\tejas\\ParabankProjectScreenshot\\Updated_phnNumber.png"));
		
		
		
	}
}
