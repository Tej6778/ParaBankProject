package com.Modules;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class M_14_AtmServices {
@Test
	public void AtmServices(WebDriver driver) throws InterruptedException {
		
//		WebDriverManager.chromedriver().setup();
//		WebDriver driver= new ChromeDriver();
//		
//		driver.get("https://parabank.parasoft.com/parabank/index.htm");
//		Thread.sleep(2000);
		
		Actions at=new Actions(driver);
		WebElement WF= driver.findElement(By.partialLinkText("Withdraw "));
		WebElement TF= driver.findElement(By.partialLinkText("Transfer "));
		WebElement CB= driver.findElement(By.partialLinkText("Check "));
		WebElement MD= driver.findElement(By.partialLinkText("Make "));
		
		at.moveToElement(WF).click().perform();
		Thread.sleep(2000);
		driver.navigate().back();
		
		at.moveToElement(TF).click().perform();
		Thread.sleep(2000);
		driver.navigate().back();
		
		at.moveToElement(CB).click().perform();
		Thread.sleep(2000);
		driver.navigate().back();
		
		at.moveToElement(MD).click().perform();
		Thread.sleep(2000);
		driver.navigate().back();
		
	}
	
}
