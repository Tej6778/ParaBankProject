package com.Modules;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

@Test
public class M_15_OnlineServices {

	public void OnlineServices(WebDriver driver) throws InterruptedException {
		
//		WebDriverManager.chromedriver().setup();
//		WebDriver driver=new ChromeDriver();
//		driver.get("https://parabank.parasoft.com/parabank/index.htm");
		Thread.sleep(2000);
		
		Actions at=new Actions(driver);
		WebElement BP= driver.findElement(By.partialLinkText("Bill "));
		WebElement AH= driver.findElement(By.partialLinkText("Account "));
		WebElement T_F= driver.findElement(By.partialLinkText("Transfer "));
		
		at.moveToElement(BP).click().perform();
		Thread.sleep(2000);
		driver.navigate().back();
		
		at.moveToElement(AH).click().perform();
		Thread.sleep(2000);
		driver.navigate().back();
		
		at.moveToElement(T_F).click().perform();
		Thread.sleep(2000);
		driver.navigate().back();
		
	}	
}
