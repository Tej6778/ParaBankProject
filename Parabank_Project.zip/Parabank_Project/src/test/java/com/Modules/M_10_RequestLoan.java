package com.Modules;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Test;

import com.google.common.io.Files;

import io.github.bonigarcia.wdm.WebDriverManager;

public class M_10_RequestLoan {

	WebDriver driver= null;
	
	
//	public void Req_Loan(WebDriver driver) throws InterruptedException {
//		WebDriverManager.chromedriver().setup();
//		driver= new ChromeDriver();
//		driver.get("https://parabank.parasoft.com/parabank/index.htm");
//		Thread.sleep(2000);
//		
//		driver.manage().window().maximize();
//			
//		driver.findElement(By.name("username")).sendKeys("DF@gmail.com");
//		Thread.sleep(1000);
//		driver.findElement(By.name("password")).sendKeys("DF@5678");
//		Thread.sleep(1000);
//		driver.findElement(By.xpath("//*[@value='Log In']")).click();
//		Thread.sleep(1000);
//	}
	
	@Test (priority = 1)
	public void Loan_with_downpayment(WebDriver driver) throws InterruptedException, IOException {
		
		driver.findElement(By.linkText("Request Loan")).click();
		Thread.sleep(1000);
		
		driver.findElement(By.id("amount")).sendKeys("10000");
		Thread.sleep(1000);
		
		driver.findElement(By.id("downPayment")).sendKeys("500");
		Thread.sleep(1000);
		
		driver.findElement(By.xpath("//input[@value='Apply Now']")).click();
		Thread.sleep(2000);
		
//		File file=((RemoteWebDriver) driver).getScreenshotAs(OutputType.FILE);
//		Files.copy(file, new File("C:\\Users\\tejas\\ParabankProjectScreenshot\\Loan with down payment.png"));
		
		String status=driver.findElement(By.id("loanStatus")).getText();
		  if (status.equals("Approved")) {
			  System.out.println("Test is Pass");
		}
		  else {
			  System.out.println("Test is failed");
		}	
	}
	
	@Test(priority = 2)
	public void Loan_with_high_downpayment(WebDriver driver) throws InterruptedException, IOException {

		driver.findElement(By.linkText("Request Loan")).click();
		Thread.sleep(1000);
		
		driver.findElement(By.id("amount")).sendKeys("10000");
		Thread.sleep(1000);
		
		driver.findElement(By.id("downPayment")).sendKeys("12000");
		Thread.sleep(1000);
		
		driver.findElement(By.xpath("//input[@value='Apply Now']")).click();
		Thread.sleep(2000);
		
		WebElement status=driver.findElement(By.id("loanStatus"));
		  if (status.getText().equals("Denied")) {
			  System.out.println("Test is Pass");
		}
		  else {
			  System.out.println("Test is Failed");
		}	
	}
		
	@Test(priority = 3)
	public void Loan_with_0_downpayment(WebDriver driver) throws InterruptedException, IOException {
		
		driver.findElement(By.linkText("Request Loan")).click();
		Thread.sleep(1000);
		
		driver.findElement(By.id("amount")).sendKeys("10000");
		Thread.sleep(1000);
		
		driver.findElement(By.id("downPayment")).sendKeys("0");
		Thread.sleep(1000);
		
		driver.findElement(By.xpath("//input[@value='Apply Now']")).click();
		Thread.sleep(2000);
		
//		File file=((RemoteWebDriver) driver).getScreenshotAs(OutputType.FILE);
//		Files.copy(file, new File("C:\\Users\\tejas\\ParabankProjectScreenshot\\Loan with_0 down payment.png"));
		
		WebElement status=driver.findElement(By.id("loanStatus"));
		  if (status.getText().equals("Denied")) {
			  System.out.println("Test is Pass");
		}
		  else {
			  System.out.println("Test is failed");
		}
		
	}	
}
