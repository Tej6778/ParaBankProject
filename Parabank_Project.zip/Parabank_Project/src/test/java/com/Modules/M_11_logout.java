package com.Modules;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class M_11_logout {
	WebDriver driver=null;
@Test
public void Logout(WebDriver driver) throws InterruptedException {

//	WebDriverManager.chromedriver().setup();
//	driver= new ChromeDriver();
//	driver.get("https://parabank.parasoft.com/parabank/index.htm");
//	Thread.sleep(2000);
//	
//	driver.manage().window().maximize();
//		
//	driver.findElement(By.name("username")).sendKeys("KY@gmail.com");
//	Thread.sleep(1000);
//	driver.findElement(By.name("password")).sendKeys("KY5678");
//	Thread.sleep(1000);
//	driver.findElement(By.xpath("//*[@value='Log In']")).click();
//	Thread.sleep(1000);

	driver.findElement(By.linkText("Log Out")).click();
	
}
}
