package com.Modules;

import java.io.File;
import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import com.google.common.io.Files;

import io.github.bonigarcia.wdm.WebDriverManager;

public class M_7_BillPay {

	
public String[][]read() throws InvalidFormatException, IOException{
	String[][]Data=null;
	String Fpath="C:\\Users\\tejas\\Desktop\\ParabankRegistration.xlsx";
	File f=new File(Fpath);
	XSSFWorkbook wrkbk=new XSSFWorkbook(f);
	Sheet st= wrkbk.getSheet("Sheet4");
	int row= st.getPhysicalNumberOfRows();
	Data=new String[row][];
	for (int i = 0; i < Data.length; i++) {
		Row rw=st.getRow(i);
		
	int col	=rw.getPhysicalNumberOfCells();
	Data[i]=new String[col];
	
	for (int j = 0; j < Data[i].length; j++) {
	Cell c=rw.getCell(j);
	c.setCellType(CellType.STRING);
	
	Data[i][j]=c.getStringCellValue();
		
	}		
	}	
	return Data;
	
}
	
WebDriver driver=null;	
public void Bpay(WebDriver driver) throws InterruptedException, InvalidFormatException, IOException {
//	WebDriverManager.chromedriver().setup();
//	driver= new ChromeDriver();
	String Data[][]=read();
	for (int i = 0; i < 1; i++) {
	
//	driver.get("https://parabank.parasoft.com/parabank/index.htm");
//	Thread.sleep(2000);
//	
//	driver.manage().window().maximize();
//		
//	driver.findElement(By.name("username")).sendKeys("MD@gmail.com");
//	Thread.sleep(1000);
//	driver.findElement(By.name("password")).sendKeys("MD@5678");
//	Thread.sleep(1000);
//	driver.findElement(By.xpath("//*[@value='Log In']")).click();
//	Thread.sleep(1000);
	driver.findElement(By.linkText("Bill Pay")).click();
	Thread.sleep(1000);
	
	driver.findElement(By.name("payee.name")).sendKeys(Data[i][0]);
	Thread.sleep(1000);
	driver.findElement(By.name("payee.address.street")).sendKeys(Data[i+1][0]);
	Thread.sleep(1000);
	driver.findElement(By.name("payee.address.city")).sendKeys(Data[i+2][0]);
	Thread.sleep(1000);
	driver.findElement(By.name("payee.address.state")).sendKeys(Data[i+3][0]);
	Thread.sleep(1000);
	driver.findElement(By.name("payee.address.zipCode")).sendKeys(Data[i+4][0]);
	Thread.sleep(1000);
	driver.findElement(By.name("payee.phoneNumber")).sendKeys(Data[i+5][0]);
	Thread.sleep(1000);
	driver.findElement(By.name("payee.accountNumber")).sendKeys(Data[i+6][0]);
	Thread.sleep(1000);
	driver.findElement(By.name("verifyAccount")).sendKeys(Data[i+7][0]);
	Thread.sleep(1000);
	driver.findElement(By.name("amount")).sendKeys(Data[i+8][0]);
	Thread.sleep(1000);
	WebElement w = driver.findElement(By.name("fromAccountId"));
	Select s= new Select(w);
	s.selectByVisibleText("13899");
	Thread.sleep(1000);
	
	driver.findElement(By.xpath("//*[@value='Send Payment']")).click();
	
	String Ttl=driver.getTitle();
	if (Ttl.equals("Bill Payment Complete")) {
		System.out.println("Test Passed ! Bill Payed with valid info");		
	} else {
		File f= ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		Files.copy(f, new File("C:\\Users\\tejas\\ParabankProjectScreenshot\\BillPay_Failed_with_Validinfo.png"));
		System.out.println("BIll Payment failed with valid info");
	}
	}
}


//	public void Bpay2() throws InterruptedException, InvalidFormatException, IOException {
//		WebDriverManager.chromedriver().setup();
//		driver= new ChromeDriver();
//		String Data[][]=read();
//		for (int i = 0; i < 1; i++) {
//		
//		driver.get("https://parabank.parasoft.com/parabank/index.htm");
//		Thread.sleep(2000);
//		
//		driver.manage().window().maximize();
//			
//		driver.findElement(By.name("username")).sendKeys("LD@gmail.com");
//		Thread.sleep(1000);
//		driver.findElement(By.name("password")).sendKeys("LD@5678");
//		Thread.sleep(1000);
//		driver.findElement(By.xpath("//*[@value='Log In']")).click();
//		Thread.sleep(1000);
//		driver.findElement(By.linkText("Bill Pay")).click();
//		Thread.sleep(1000);
//		
//		driver.findElement(By.name("payee.name")).sendKeys(Data[i][0]);
//		Thread.sleep(1000);
//		driver.findElement(By.name("payee.address.street")).sendKeys(Data[i+1][0]);
//		Thread.sleep(1000);
//		driver.findElement(By.name("payee.address.city")).sendKeys(Data[i+2][0]);
//		Thread.sleep(1000);
//		driver.findElement(By.name("payee.address.state")).sendKeys(Data[i+3][0]);
//		Thread.sleep(1000);
//		driver.findElement(By.name("payee.address.zipCode")).sendKeys(Data[i+4][0]);
//		Thread.sleep(1000);
//		driver.findElement(By.name("payee.phoneNumber")).sendKeys(Data[i+5][0]);
//		Thread.sleep(1000);
//		driver.findElement(By.name("payee.accountNumber")).sendKeys(Data[i+6][0]);
//		Thread.sleep(1000);
//		driver.findElement(By.name("verifyAccount")).sendKeys(Data[i+7][0]);
//		Thread.sleep(1000);
//		driver.findElement(By.name("amount")).sendKeys(Data[i+8][0]);
//		Thread.sleep(1000);
//		WebElement w = driver.findElement(By.name("fromAccountId"));
//		Select s= new Select(w);
//		s.selectByVisibleText("13788");
//		Thread.sleep(1000);
//		
//		driver.findElement(By.xpath("//*[@value='Send Payment']")).click();
//		
//		String ss=driver.findElement(By.cssSelector("p[class='error']")).getText();
//		
//		if (ss.equals("Bill Payment Complete")) {
//			File f= ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
//			Files.copy(f, new File("C:\\Users\\tejas\\ParabankProjectScreenshot\\BillPayed_with_Blankinfo.png"));
//			System.out.println("Test Failed ! Bill Payed without phn number");		
//		} else {
//			System.out.println("Test Passed ! BIll Payment failed with blank info");
//		}
//		}
//	}
	
	
	
	
	
	
//	String Ttl1=driver.findElement(By.xpath("//*[@id=\"rightPanel\"]/div/div[1]/form/table/tbody/tr[8]/td[3]/span[1]")).getText();
//	//System.out.println(Ttl1);
//	if (Ttl1.equals("Account number is required.")) {
//		File f1= ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
//		Files.copy(f1, new File("C:\\Users\\tejas\\ParabankProjectScreenshot\\BillPay1(without Account Number).png"));
//		System.out.println("Test Passed ! Bill Payment failed due to blank a/c");
//	} else {
//		System.out.println("Test Failed! BIll paid with blank a/c info");
//	}
//
//	String Ttl2= driver.findElement(By.xpath("//*[@id=\"rightPanel\"]/div/div[1]/form/table/tbody/tr[11]/td[3]/span[1]")).getText();
//	//System.out.println(Ttl2);
//	if (Ttl2.equals("The amount cannot be empty.")) {
//		File f1= ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
//		Files.copy(f1, new File("C:\\Users\\tejas\\ParabankProjectScreenshot\\BillPay1(without Amount).png"));
//		System.out.println("Test Passed ! Bill Payment failed due to blank amount");
//	} else {
//		System.out.println("Test Failed! BIll paid with blank amount info");
//	}
	
	
}

