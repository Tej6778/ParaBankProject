package com.Modules;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
@Test
public class M_17_FooterLinks {

	public void FLinks(WebDriver driver) throws InterruptedException {
//		WebDriverManager.chromedriver().setup();
//		WebDriver driver=new ChromeDriver();
//		driver.manage().window().maximize();
//		driver.get("https://parabank.parasoft.com/parabank/index.htm");
		Thread.sleep(2000);
		
		Actions at=new Actions(driver);
		
	WebElement HM= driver.findElement(By.linkText("Home"));
	WebElement Abt= driver.findElement(By.linkText("About Us"));
	WebElement Srvs= driver.findElement(By.linkText("Services"));
	WebElement Prd= driver.findElement(By.linkText("Products"));
	WebElement Lc= driver.findElement(By.linkText("Locations"));
	WebElement Frm= driver.findElement(By.linkText("Forum"));
	WebElement SM= driver.findElement(By.linkText("Site Map"));
	WebElement CntctUs= driver.findElement(By.linkText("Contact Us"));
	
	at.moveToElement(HM).click().perform();
	Thread.sleep(2000);
	driver.navigate().back();
	
	at.moveToElement(Abt).click().perform();
	Thread.sleep(2000);
	driver.navigate().back();
	
	at.moveToElement(Srvs).click().perform();
	Thread.sleep(2000);
	driver.navigate().back();
	
	at.moveToElement(Prd).click().perform();
	Thread.sleep(2000);
	driver.navigate().back();
	
	at.moveToElement(Lc).click().perform();
	Thread.sleep(2000);
	driver.navigate().back();
	
	at.moveToElement(Frm).click().perform();
	Thread.sleep(2000);
	driver.navigate().back();
	
	at.moveToElement(SM).click().perform();
	Thread.sleep(2000);
	driver.navigate().back();
	
	at.moveToElement(CntctUs).click().perform();
	Thread.sleep(2000);
	driver.navigate().back();
	
	driver.close();
	}
	
}
