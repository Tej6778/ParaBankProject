package com.Modules;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class M_8_FindTransactions {
	
WebDriver driver=null;
@Test
public void FindTransactions(WebDriver driver) throws InterruptedException {
//	WebDriverManager.chromedriver().setup();
//	driver= new ChromeDriver();
//	driver.get("https://parabank.parasoft.com/parabank/index.htm");
//	Thread.sleep(2000);
//	
//	driver.manage().window().maximize();
//		
//	driver.findElement(By.name("username")).sendKeys("DF@gmail.com");
//	Thread.sleep(1000);
//	driver.findElement(By.name("password")).sendKeys("DF@5678");
//	Thread.sleep(1000);
//	driver.findElement(By.xpath("//*[@value='Log In']")).click();
//	Thread.sleep(1000);
//	
}

@Test 
public void BY_ID(WebDriver driver) throws InterruptedException {

	driver.findElement(By.linkText("Find Transactions")).click();
	Thread.sleep(1000);
	
	driver.findElement(By.id("criteria.transactionId")).sendKeys("23456");
	Thread.sleep(1000);
	
	driver.findElement(By.xpath("//*[@id=\"rightPanel\"]/div/div/form/div[3]/button")).click();
	Thread.sleep(1000);		
}

@Test
public void BY_Date(WebDriver driver) throws InterruptedException {
	
	driver.findElement(By.linkText("Find Transactions")).click();
	Thread.sleep(1000);	
	driver.findElement(By.id("criteria.onDate")).sendKeys("02-08-2024");
	Thread.sleep(1000);
	driver.findElement(By.xpath("//*[@id=\"rightPanel\"]/div/div/form/div[5]/button")).click();
	Thread.sleep(1000);	
}

@Test
public void BY_DateRange(WebDriver driver) throws InterruptedException {
	
	driver.findElement(By.linkText("Find Transactions")).click();
	Thread.sleep(1000);	
	driver.findElement(By.id("criteria.fromDate")).sendKeys("02-05-2024");
	Thread.sleep(1000);
	driver.findElement(By.id("criteria.toDate")).sendKeys("02-08-2024");
	Thread.sleep(1000);
	driver.findElement(By.xpath("//*[@id=\"rightPanel\"]/div/div/form/div[7]/button")).click();
	Thread.sleep(1000);	
}

@Test
public void BY_Amount(WebDriver driver) throws InterruptedException {
	
	driver.findElement(By.linkText("Find Transactions")).click();
	Thread.sleep(1000);	
	driver.findElement(By.id("criteria.amount")).sendKeys("10");
	Thread.sleep(1000);
	driver.findElement(By.xpath("//*[@id=\"rightPanel\"]/div/div/form/div[9]/button")).click();
	Thread.sleep(1000);	
}

}
