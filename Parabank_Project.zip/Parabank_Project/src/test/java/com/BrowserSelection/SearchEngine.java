package com.BrowserSelection;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class SearchEngine {

	WebDriver driver=null;
	
public WebDriver Edgebrowser(String browser, String url) {

if (browser.equals("edge") || browser.equals("Edge") || browser.equals("EDGE")) {
	
System.setProperty("webdriver.edge.driver", "C:\\Users\\tejas\\edgedriver_win64\\msedgedriver.exe");

WebDriverManager.edgedriver().setup();	
driver=new EdgeDriver();
driver.manage().window().maximize();
driver.get(url);

}	

return driver;
}
		
}
